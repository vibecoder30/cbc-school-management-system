# CBC Integrated School Management System

Multi-tenant School Management + Learning platform for **20+ schools**, fully aligned to Kenya’s **Competency-Based Curriculum (CBC / 2-6-3-3-3)**.

## Key Features

- **Instant school registration** → school code + admin username & password generated immediately
- **Multi-tenant isolation** – each school’s data is separated by `school_id`
- **CBC structure seeded automatically** on registration:
  - Grades: PP1, PP2, Grade 1–12
  - Subjects per stage (Pre-Primary, Lower/Upper Primary, Junior & Senior Secondary)
- **Integrated Learning Hub** – create modules with strands, sub-strands, learning outcomes
- **Exams** – formative / summative / national-prep with MCQ auto-marking
- **CBC Achievement Levels** – EE1/EE2, ME1/ME2, AE1/AE2, BE1/BE2
- **School-based continuous assessments**
- Roles: Platform Admin, School Admin, Teacher, Student

## Quick Start

```bash
cd /home/workdir/artifacts/cbc_sms
python3 app.py
```

Open http://127.0.0.1:5000

### Platform Admin
- Username: `platform_admin`
- Password: `Platform@2026`
- (Leave School Code blank)

### Register a School
1. Go to **Register School**
2. Fill school + admin details
3. You receive **School Code**, **Username**, **Password** instantly
4. Login with School Code + credentials

### Typical flow after registration
1. School Admin creates **Classes** (linked to CBC grades)
2. Adds **Teachers** and **Students** (credentials auto-generated)
3. Teachers create **Learning Modules** and **Exams**
4. Students take exams and view results with achievement levels
5. Teachers record continuous assessments (SBA)

## Tech Stack
- Python 3 + Flask
- SQLAlchemy + SQLite (easy to switch to PostgreSQL)
- Flask-Login
- Bootstrap 5 UI

## Notes for production
- Change `SECRET_KEY` and platform admin password
- Use PostgreSQL + proper migrations
- Add HTTPS, rate limiting, email notifications
- Scale horizontally; current design supports 20+ schools comfortably on modest hardware
